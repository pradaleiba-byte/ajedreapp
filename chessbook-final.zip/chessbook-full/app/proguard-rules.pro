# Chessbook ProGuard rules
-keep class com.chessbook.** { *; }
-keep class com.github.bhlangonijr.** { *; }
-keepattributes *Annotation*
-dontwarn kotlin.**
