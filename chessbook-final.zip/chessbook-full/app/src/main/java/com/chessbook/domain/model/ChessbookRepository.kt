package com.chessbook.domain.model

import com.chessbook.data.dao.RepertoireDao
import com.chessbook.data.dao.RepertoireNodeDao
import com.chessbook.data.entity.Repertoire
import com.chessbook.data.entity.RepertoireNode
import com.chessbook.data.entity.ReviewStatus
import com.chessbook.domain.algorithm.SM2Algorithm
import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.pgn.PgnHolder
import kotlinx.coroutines.flow.Flow

class ChessbookRepository(
    private val repertoireDao: RepertoireDao,
    private val nodeDao: RepertoireNodeDao
) {
    // ── Repertorios ──────────────────────────────────────────────────────────
    fun getAllRepertoires(): Flow<List<Repertoire>> = repertoireDao.getAllFlow()
    suspend fun createRepertoire(r: Repertoire): Long = repertoireDao.insert(r)
    suspend fun deleteRepertoire(r: Repertoire) {
        nodeDao.deleteAllForRepertoire(r.id)
        repertoireDao.delete(r)
    }

    // ── Importar PGN ─────────────────────────────────────────────────────────
    suspend fun importPgn(pgnText: String, repertoireId: Long): Int {
        val nodes = parsePgn(pgnText, repertoireId)
        nodeDao.insertAll(nodes.map { it.copy(id = 0) })
        return nodes.size
    }

    private fun parsePgn(pgnText: String, repertoireId: Long): List<RepertoireNode> {
        val result = mutableListOf<RepertoireNode>()
        return try {
            val pgn = PgnHolder()
            pgn.loadPgn(pgnText)
            for (game in pgn.games) {
                game.loadMoveText()
                val board = Board()
                var parentId: Long? = null
                var tempId = 1L
                for (move in game.halfMoves) {
                    val san = move.san ?: continue
                    val legal = board.legalMoves().firstOrNull { it.san == san } ?: continue
                    val node = RepertoireNode(
                        id = tempId++, repertoireId = repertoireId,
                        parentMoveId = parentId, fen = board.fen,
                        moveSan = san, comment = move.comment ?: "",
                        status = ReviewStatus.NEW
                    )
                    result.add(node)
                    board.doMove(legal)
                    parentId = node.id
                }
            }
            result
        } catch (e: Exception) {
            result
        }
    }

    // ── Entrenamiento ────────────────────────────────────────────────────────
    suspend fun getNextDueNode(repertoireId: Long): RepertoireNode? =
        nodeDao.getNextDueNode(repertoireId)

    suspend fun submitReview(node: RepertoireNode, quality: Int) =
        nodeDao.update(SM2Algorithm.calculateNextReview(node, quality))

    fun getIntervalLabel(node: RepertoireNode, quality: Int) =
        SM2Algorithm.getIntervalLabel(node, quality)

    // ── Stats ────────────────────────────────────────────────────────────────
    fun getDueCountFlow(repertoireId: Long) = nodeDao.getDueCountFlow(repertoireId)
    fun getTotalDueCountFlow() = nodeDao.getTotalDueCountFlow()
    fun getAllNodesFlow(repertoireId: Long) = nodeDao.getAllNodesFlow(repertoireId)
    fun getTotalCount(repertoireId: Long) = nodeDao.getTotalCount(repertoireId)
    fun getCountByStatus(repertoireId: Long, status: ReviewStatus) =
        nodeDao.getCountByStatus(repertoireId, status)
}
