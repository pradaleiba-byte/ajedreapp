package com.chessbook.ui.repertoire
import androidx.lifecycle.*
import androidx.lifecycle.viewModelScope
import com.chessbook.data.entity.PlayerColor
import com.chessbook.data.entity.Repertoire
import com.chessbook.domain.model.ChessbookRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

sealed interface RepertoireUiState {
    object Loading : RepertoireUiState
    data class Success(val repertoires: List<Repertoire>) : RepertoireUiState
    data class Error(val message: String) : RepertoireUiState
}

class RepertoireViewModel(private val repository: ChessbookRepository) : ViewModel() {

    val uiState: StateFlow<RepertoireUiState> = repository.getAllRepertoires()
        .map<List<Repertoire>, RepertoireUiState> { RepertoireUiState.Success(it) }
        .catch { emit(RepertoireUiState.Error(it.message ?: "Error desconocido")) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), RepertoireUiState.Loading)

    fun createRepertoire(name: String, color: PlayerColor) {
        viewModelScope.launch {
            repository.createRepertoire(
                Repertoire(name = name, playerColor = color)
            )
        }
    }

    fun importPgn(pgnText: String, repertoireId: Long) {
        viewModelScope.launch {
            repository.importPgn(pgnText, repertoireId)
        }
    }

    fun deleteRepertoire(r: Repertoire) {
        viewModelScope.launch { repository.deleteRepertoire(r) }
    }

    class Factory(private val repository: ChessbookRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            RepertoireViewModel(repository) as T
    }
}
