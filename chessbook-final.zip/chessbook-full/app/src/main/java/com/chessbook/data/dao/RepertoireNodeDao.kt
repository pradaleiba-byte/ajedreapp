package com.chessbook.data.dao
import androidx.room.*
import com.chessbook.data.entity.RepertoireNode
import com.chessbook.data.entity.ReviewStatus
import kotlinx.coroutines.flow.Flow
@Dao
interface RepertoireNodeDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(node: RepertoireNode): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(nodes: List<RepertoireNode>)
    @Update suspend fun update(node: RepertoireNode)
    @Delete suspend fun delete(node: RepertoireNode)
    @Query("DELETE FROM repertoire_nodes WHERE repertoireId = :repertoireId") suspend fun deleteAllForRepertoire(repertoireId: Long)
    @Query("SELECT * FROM repertoire_nodes WHERE repertoireId = :repertoireId AND due_date <= :now ORDER BY due_date ASC LIMIT 1")
    suspend fun getNextDueNode(repertoireId: Long, now: Long = System.currentTimeMillis()): RepertoireNode?
    @Query("SELECT COUNT(*) FROM repertoire_nodes WHERE repertoireId = :repertoireId AND due_date <= :now")
    fun getDueCountFlow(repertoireId: Long, now: Long = System.currentTimeMillis()): Flow<Int>
    @Query("SELECT COUNT(*) FROM repertoire_nodes WHERE due_date <= :now")
    fun getTotalDueCountFlow(now: Long = System.currentTimeMillis()): Flow<Int>
    @Query("SELECT * FROM repertoire_nodes WHERE repertoireId = :repertoireId ORDER BY id ASC")
    fun getAllNodesFlow(repertoireId: Long): Flow<List<RepertoireNode>>
    @Query("SELECT COUNT(*) FROM repertoire_nodes WHERE repertoireId = :repertoireId")
    fun getTotalCount(repertoireId: Long): Flow<Int>
    @Query("SELECT COUNT(*) FROM repertoire_nodes WHERE repertoireId = :repertoireId AND status = :status")
    fun getCountByStatus(repertoireId: Long, status: ReviewStatus): Flow<Int>
}
