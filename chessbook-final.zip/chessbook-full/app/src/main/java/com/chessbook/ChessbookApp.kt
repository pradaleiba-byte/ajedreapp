package com.chessbook

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.chessbook.data.db.ChessbookDatabase
import com.chessbook.domain.model.ChessbookRepository
import com.chessbook.ui.progress.ProgressScreen
import com.chessbook.ui.repertoire.RepertoireScreen
import com.chessbook.ui.repertoire.RepertoireViewModel
import com.chessbook.ui.theme.ChessbookTheme
import com.chessbook.ui.training.TrainingScreen
import com.chessbook.ui.training.TrainingViewModel

// ── Application ───────────────────────────────────────────────────────────────

class ChessbookApp : Application() {
    val database by lazy { ChessbookDatabase.getInstance(this) }
    val repository by lazy {
        ChessbookRepository(database.repertoireDao(), database.repertoireNodeDao())
    }
}

// ── MainActivity ──────────────────────────────────────────────────────────────

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ChessbookTheme {
                ChessbookNavigation()
            }
        }
    }
}

// ── Navegación ────────────────────────────────────────────────────────────────

enum class Screen { REPERTOIRES, TRAINING, PROGRESS }

@Composable
fun ChessbookNavigation() {
    val app = LocalContext.current.applicationContext as ChessbookApp
    var currentScreen by remember { mutableStateOf(Screen.REPERTOIRES) }
    var activeRepertoireId by remember { mutableStateOf<Long?>(null) }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            if (activeRepertoireId != null) {
                NavigationBar {
                    NavigationBarItem(
                        selected = currentScreen == Screen.TRAINING,
                        onClick  = { currentScreen = Screen.TRAINING },
                        icon     = { Icon(Icons.Outlined.PlayArrow, null) },
                        label    = { Text("Entrenar") }
                    )
                    NavigationBarItem(
                        selected = currentScreen == Screen.REPERTOIRES,
                        onClick  = { currentScreen = Screen.REPERTOIRES },
                        icon     = { Icon(Icons.Outlined.List, null) },
                        label    = { Text("Repertorio") }
                    )
                    NavigationBarItem(
                        selected = currentScreen == Screen.PROGRESS,
                        onClick  = { currentScreen = Screen.PROGRESS },
                        icon     = { Icon(Icons.Outlined.BarChart, null) },
                        label    = { Text("Progreso") }
                    )
                }
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding)) {
            when {
                activeRepertoireId == null || currentScreen == Screen.REPERTOIRES -> {
                    val vm: RepertoireViewModel = viewModel(
                        factory = RepertoireViewModel.Factory(app.repository)
                    )
                    RepertoireScreen(
                        viewModel = vm,
                        onStartTraining = { id ->
                            activeRepertoireId = id
                            currentScreen = Screen.TRAINING
                        }
                    )
                }
                currentScreen == Screen.TRAINING -> {
                    val vm: TrainingViewModel = viewModel(
                        key     = "training_${activeRepertoireId}",
                        factory = TrainingViewModel.Factory(app.repository, activeRepertoireId!!)
                    )
                    TrainingScreen(viewModel = vm)
                }
                currentScreen == Screen.PROGRESS -> {
                    ProgressScreen(
                        repository    = app.repository,
                        repertoireId  = activeRepertoireId!!
                    )
                }
            }
        }
    }
}
