package com.chessbook.data.db
import android.content.Context
import androidx.room.*
import com.chessbook.data.dao.RepertoireDao
import com.chessbook.data.dao.RepertoireNodeDao
import com.chessbook.data.entity.*
class Converters {
    @TypeConverter fun fromReviewStatus(v: ReviewStatus): String = v.name
    @TypeConverter fun toReviewStatus(v: String): ReviewStatus = ReviewStatus.valueOf(v)
    @TypeConverter fun fromPlayerColor(v: PlayerColor): String = v.name
    @TypeConverter fun toPlayerColor(v: String): PlayerColor = PlayerColor.valueOf(v)
}
@Database(entities = [Repertoire::class, RepertoireNode::class], version = 1, exportSchema = false)
@TypeConverters(Converters::class)
abstract class ChessbookDatabase : RoomDatabase() {
    abstract fun repertoireDao(): RepertoireDao
    abstract fun repertoireNodeDao(): RepertoireNodeDao
    companion object {
        @Volatile private var INSTANCE: ChessbookDatabase? = null
        fun getInstance(context: Context): ChessbookDatabase =
            INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(context.applicationContext, ChessbookDatabase::class.java, "chessbook.db")
                    .fallbackToDestructiveMigration().build().also { INSTANCE = it }
            }
    }
}
