package com.chessbook.data.entity
import androidx.room.*
enum class ReviewStatus { NEW, LEARNING, REVIEW, RELEARNING }
@Entity(tableName = "repertoire_nodes")
data class RepertoireNode(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val repertoireId: Long,
    val parentMoveId: Long? = null,
    val fen: String,
    val moveSan: String,
    val isMainLine: Boolean = true,
    val comment: String = "",
    @ColumnInfo(name = "due_date") val dueDate: Long = System.currentTimeMillis(),
    val interval: Int = 0,
    val easeFactor: Float = 2.5f,
    val repetitions: Int = 0,
    val status: ReviewStatus = ReviewStatus.NEW
)
