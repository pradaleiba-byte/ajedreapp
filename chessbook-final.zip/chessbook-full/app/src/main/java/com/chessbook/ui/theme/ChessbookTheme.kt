package com.chessbook.ui.theme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
private val LightColors = lightColorScheme(
    primary = Color(0xFF6B4226), onPrimary = Color.White,
    primaryContainer = Color(0xFFF0D9B5), onPrimaryContainer = Color(0xFF6B4226),
    secondary = Color(0xFFB58863), onSecondary = Color.White,
    background = Color(0xFFFFFBF7), surface = Color(0xFFFFFBF7),
)
@Composable
fun ChessbookTheme(darkTheme: Boolean = false, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = LightColors, content = content)
}
