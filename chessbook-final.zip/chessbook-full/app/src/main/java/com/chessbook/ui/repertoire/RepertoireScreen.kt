package com.chessbook.ui.repertoire

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.chessbook.data.entity.PlayerColor
import com.chessbook.data.entity.Repertoire

@Composable
fun RepertoireScreen(
    viewModel: RepertoireViewModel,
    onStartTraining: (Long) -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    var showImportDialog by remember { mutableStateOf(false) }
    var importTargetId by remember { mutableStateOf<Long?>(null) }
    var showCreateDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Mis repertorios") }) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                text  = { Text("Nuevo") },
                icon  = { Icon(Icons.Outlined.Add, contentDescription = null) },
                onClick = { showCreateDialog = true }
            )
        }
    ) { padding ->
        Box(Modifier.padding(padding)) {
            when (val s = uiState) {
                is RepertoireUiState.Loading -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                    CircularProgressIndicator()
                }
                is RepertoireUiState.Error -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                    Text(s.message, color = MaterialTheme.colorScheme.error)
                }
                is RepertoireUiState.Success -> {
                    if (s.repertoires.isEmpty()) {
                        EmptyState { showCreateDialog = true }
                    } else {
                        RepertoireList(
                            repertoires = s.repertoires,
                            onTrain     = { onStartTraining(it.id) },
                            onImport    = { importTargetId = it.id; showImportDialog = true },
                            onDelete    = { viewModel.deleteRepertoire(it) }
                        )
                    }
                }
            }
        }
    }

    if (showImportDialog) {
        ImportPgnDialog(
            onDismiss = { showImportDialog = false },
            onConfirm = { pgn ->
                importTargetId?.let { viewModel.importPgn(pgn, it) }
                showImportDialog = false
            }
        )
    }

    if (showCreateDialog) {
        CreateRepertoireDialog(
            onDismiss = { showCreateDialog = false },
            onCreate  = { name, color ->
                viewModel.createRepertoire(name, color)
                showCreateDialog = false
            }
        )
    }
}

/* ─────────────────────── Sub-composables ─────────────────────── */

@Composable
private fun EmptyState(onCreate: () -> Unit) {
    Box(Modifier.fillMaxSize(), Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Sin repertorios", fontSize = 20.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(8.dp))
            Text(
                "Crea uno e importa un PGN para empezar a entrenar.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(20.dp))
            Button(onClick = onCreate) { Text("Crear mi primer repertorio") }
        }
    }
}

@Composable
private fun RepertoireList(
    repertoires: List<Repertoire>,
    onTrain:  (Repertoire) -> Unit,
    onImport: (Repertoire) -> Unit,
    onDelete: (Repertoire) -> Unit
) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(repertoires, key = { it.id }) { rep ->
            RepertoireCard(rep, onTrain, onImport, onDelete)
        }
    }
}

@Composable
private fun RepertoireCard(
    rep:      Repertoire,
    onTrain:  (Repertoire) -> Unit,
    onImport: (Repertoire) -> Unit,
    onDelete: (Repertoire) -> Unit
) {
    var showDelete by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text(rep.name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                AssistChip(
                    onClick = {},
                    label   = {
                        Text(
                            if (rep.playerColor == PlayerColor.WHITE) "♔ Blancas" else "♚ Negras",
                            fontSize = 11.sp
                        )
                    }
                )
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { onTrain(rep) }, Modifier.weight(1f))           { Text("Entrenar") }
                OutlinedButton(onClick = { onImport(rep) }, Modifier.weight(1f))  { Text("PGN") }
                IconButton(onClick = { showDelete = true }) {
                    Text("🗑", fontSize = 16.sp)
                }
            }
        }
    }
    if (showDelete) {
        AlertDialog(
            onDismissRequest = { showDelete = false },
            title  = { Text("Eliminar repertorio") },
            text   = { Text("¿Seguro que quieres eliminar «${rep.name}»? Se perderán todas las jugadas.") },
            confirmButton = {
                Button(
                    onClick = { onDelete(rep); showDelete = false },
                    colors  = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text("Eliminar") }
            },
            dismissButton = { TextButton({ showDelete = false }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun ImportPgnDialog(onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var pgn by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Importar PGN") },
        text  = {
            Column {
                Text(
                    "Pega aquí el texto PGN de tu apertura.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value       = pgn,
                    onValueChange = { pgn = it },
                    modifier    = Modifier.fillMaxWidth().height(200.dp),
                    placeholder = { Text("1. e4 e5 2. Nf3 Nc6 ...") },
                    maxLines    = 12
                )
            }
        },
        confirmButton = {
            Button(
                onClick  = { if (pgn.isNotBlank()) onConfirm(pgn) },
                enabled  = pgn.isNotBlank()
            ) { Text("Importar") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun CreateRepertoireDialog(onDismiss: () -> Unit, onCreate: (String, PlayerColor) -> Unit) {
    var name  by remember { mutableStateOf("") }
    var color by remember { mutableStateOf(PlayerColor.WHITE) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nuevo repertorio") },
        text  = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value         = name,
                    onValueChange = { name = it },
                    modifier      = Modifier.fillMaxWidth(),
                    label         = { Text("Nombre") },
                    placeholder   = { Text("Apertura Inglesa, Defensa Siciliana…") },
                    singleLine    = true
                )
                Text("Juego con:", fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FilterChip(
                        selected = color == PlayerColor.WHITE,
                        onClick  = { color = PlayerColor.WHITE },
                        label    = { Text("♔ Blancas") }
                    )
                    FilterChip(
                        selected = color == PlayerColor.BLACK,
                        onClick  = { color = PlayerColor.BLACK },
                        label    = { Text("♚ Negras") }
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick  = { if (name.isNotBlank()) onCreate(name, color) },
                enabled  = name.isNotBlank()
            ) { Text("Crear") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancelar") } }
    )
}
