package com.chessbook.ui.progress

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.chessbook.data.entity.ReviewStatus
import com.chessbook.domain.model.ChessbookRepository
import kotlinx.coroutines.flow.Flow

@Composable
fun ProgressScreen(repository: ChessbookRepository, repertoireId: Long) {
    val totalDue by repository.getTotalDueCountFlow().collectAsStateWithLifecycle(0)
    val totalNodes by repository.getTotalCount(repertoireId).collectAsStateWithLifecycle(0)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Tu progreso", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)

        // Stats rápidas
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            StatCard("Pendientes hoy", "$totalDue", Color(0xFFF7C1C1), Modifier.weight(1f))
            StatCard("Total jugadas", "$totalNodes", Color(0xFFB5D4F4), Modifier.weight(1f))
        }

        // Distribución por estado
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Estado del repertorio", fontWeight = FontWeight.Medium, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(12.dp))
                StatusRow("Nuevas", ReviewStatus.NEW, Color(0xFFCED3E0), repository, repertoireId)
                StatusRow("Aprendiendo", ReviewStatus.LEARNING, Color(0xFFFAC775), repository, repertoireId)
                StatusRow("Repaso", ReviewStatus.REVIEW, Color(0xFF85B7EB), repository, repertoireId)
                StatusRow("Reaprendiendo", ReviewStatus.RELEARNING, Color(0xFFF09595), repository, repertoireId)
            }
        }

        // Consejo
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFE1F5EE))
        ) {
            Row(modifier = Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("💡", fontSize = 20.sp)
                Text(
                    "Estudia al menos 10 jugadas al día para mantener el repertorio fresco. La constancia es más importante que la cantidad.",
                    fontSize = 13.sp,
                    color = Color(0xFF04342C),
                    lineHeight = 20.sp
                )
            }
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, bgColor: Color, modifier: Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = bgColor)) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(value, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text(label, fontSize = 12.sp, color = Color(0xFF333333))
        }
    }
}

@Composable
private fun StatusRow(
    label: String,
    status: ReviewStatus,
    color: Color,
    repository: ChessbookRepository,
    repertoireId: Long
) {
    val count by repository.getCountByStatus(repertoireId, status).collectAsStateWithLifecycle(0)
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(10.dp).background(color, RoundedCornerShape(2.dp)))
            Text(label, fontSize = 13.sp)
        }
        Text("$count", fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}
