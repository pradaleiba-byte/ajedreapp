package com.chessbook.data.entity
import androidx.room.*
enum class PlayerColor { WHITE, BLACK }
@Entity(tableName = "repertoires")
data class Repertoire(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val playerColor: PlayerColor,
    val createdAt: Long = System.currentTimeMillis(),
    val lastStudiedAt: Long? = null
)
