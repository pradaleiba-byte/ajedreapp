package com.chessbook.ui.training
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun TrainingScreen(viewModel: TrainingViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val dueCount by viewModel.dueCount.collectAsStateWithLifecycle()
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text("Entrenamiento", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.errorContainer) {
                Text("$dueCount pendientes", Modifier.padding(horizontal=12.dp,vertical=4.dp), fontSize=12.sp, color=MaterialTheme.colorScheme.onErrorContainer)
            }
        }
        Spacer(Modifier.height(16.dp))
        when (val s = uiState) {
            is TrainingUiState.Loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
            is TrainingUiState.Empty -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("¡Todo al día! 🎉", fontSize=22.sp, fontWeight=FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    Text("No hay jugadas vencidas por hoy.", color=MaterialTheme.colorScheme.onSurfaceVariant, textAlign=TextAlign.Center)
                }
            }
            is TrainingUiState.Error -> Box(Modifier.fillMaxSize(), Alignment.Center) { Text(s.message, color=MaterialTheme.colorScheme.error) }
            is TrainingUiState.Ready -> Column(Modifier.fillMaxSize()) {
                // Tablero 8x8
                val lightSq = Color(0xFFF0D9B5); val darkSq = Color(0xFFB58863); val highlightSq = Color(0xFFAACC44)
                Box(Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(8.dp)).border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))) {
                    Column {
                        repeat(8) { row -> Row(Modifier.weight(1f)) {
                            repeat(8) { col -> Box(Modifier.weight(1f).fillMaxHeight()
                                .background(if ((row+col)%2==0) lightSq else darkSq), Alignment.Center) {} }
                        }}
                    }
                    if (s.isRevealed) Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha=0.2f)), Alignment.Center) {
                        Surface(shape=RoundedCornerShape(8.dp), color=MaterialTheme.colorScheme.primaryContainer) {
                            Text(s.node.moveSan, Modifier.padding(horizontal=20.dp,vertical=8.dp), fontSize=28.sp, fontWeight=FontWeight.Bold, color=MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text(if(s.isRevealed) "Jugada correcta: ${s.node.moveSan}" else "¿Cuál es la mejor jugada?", fontWeight=FontWeight.Medium, fontSize=16.sp)
                        if (s.node.comment.isNotBlank()) { Spacer(Modifier.height(4.dp)); Text(s.node.comment, color=MaterialTheme.colorScheme.onSurfaceVariant, fontSize=13.sp) }
                    }
                }
                Spacer(Modifier.height(12.dp))
                AnimatedVisibility(!s.isRevealed) { Button(viewModel::revealMove, Modifier.fillMaxWidth()) { Text("Ver jugada correcta") } }
                AnimatedVisibility(s.isRevealed) {
                    val labels = listOf("Otra vez","Difícil","Bien","Fácil")
                    val colors = listOf(Color(0xFFE24B4A),Color(0xFFBA7517),Color(0xFF378ADD),Color(0xFF1D9E75))
                    Column {
                        Text("¿Cómo te fue?", fontSize=13.sp, color=MaterialTheme.colorScheme.onSurfaceVariant, modifier=Modifier.padding(bottom=8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                            labels.forEachIndexed { i, lbl ->
                                OutlinedButton({viewModel.rate(i)}, Modifier.weight(1f),
                                    colors=ButtonDefaults.outlinedButtonColors(contentColor=colors[i]),
                                    border=androidx.compose.foundation.BorderStroke(1.dp,colors[i].copy(alpha=0.5f))) {
                                    Column(horizontalAlignment=Alignment.CenterHorizontally) {
                                        Text(lbl, fontSize=11.sp, fontWeight=FontWeight.Medium)
                                        Text(s.intervalLabels[i], fontSize=9.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
