package com.chessbook.domain.algorithm
import com.chessbook.data.entity.RepertoireNode
import com.chessbook.data.entity.ReviewStatus
object SM2Algorithm {
    private const val MIN_EASE = 1.3f
    fun calculateNextReview(node: RepertoireNode, quality: Int): RepertoireNode {
        require(quality in 0..3)
        val now = System.currentTimeMillis()
        return when {
            quality == 0 -> node.copy(repetitions=0, interval=0,
                easeFactor=(node.easeFactor-0.2f).coerceAtLeast(MIN_EASE),
                dueDate=now+60_000L, status=ReviewStatus.RELEARNING)
            node.repetitions == 0 -> node.copy(repetitions=1, interval=1,
                easeFactor=adjustEase(node.easeFactor,quality),
                dueDate=now+daysMs(1), status=ReviewStatus.LEARNING)
            node.repetitions == 1 -> node.copy(repetitions=2, interval=6,
                easeFactor=adjustEase(node.easeFactor,quality),
                dueDate=now+daysMs(6), status=ReviewStatus.LEARNING)
            else -> {
                val interval = when(quality) {
                    1 -> (node.interval*1.2f).toInt().coerceAtLeast(node.interval+1)
                    3 -> (node.interval*node.easeFactor*1.3f).toInt()
                    else -> (node.interval*node.easeFactor).toInt()
                }
                node.copy(repetitions=node.repetitions+1, interval=interval,
                    easeFactor=adjustEase(node.easeFactor,quality),
                    dueDate=now+daysMs(interval), status=ReviewStatus.REVIEW)
            }
        }
    }
    fun getIntervalLabel(node: RepertoireNode, quality: Int): String = when {
        quality == 0 -> "< 1 min"
        node.repetitions == 0 -> "1 día"
        node.repetitions == 1 -> "6 días"
        quality == 1 -> "${(node.interval*1.2f).toInt()} días"
        quality == 3 -> "${(node.interval*node.easeFactor*1.3f).toInt()} días"
        else -> "${(node.interval*node.easeFactor).toInt()} días"
    }
    private fun adjustEase(ef: Float, q: Int): Float =
        (ef+0.1f-(3-q)*(0.08f+(3-q)*0.02f)).coerceAtLeast(MIN_EASE)
    private fun daysMs(days: Int): Long = days*86_400_000L
}
