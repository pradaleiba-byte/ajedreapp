package com.chessbook.ui.training
import androidx.lifecycle.*
import androidx.lifecycle.viewModelScope
import com.chessbook.data.entity.RepertoireNode
import com.chessbook.domain.algorithm.SM2Algorithm
import com.chessbook.domain.model.ChessbookRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
sealed interface TrainingUiState {
    object Loading : TrainingUiState
    object Empty : TrainingUiState
    data class Ready(val node: RepertoireNode, val isRevealed: Boolean = false, val intervalLabels: List<String>) : TrainingUiState
    data class Error(val message: String) : TrainingUiState
}
class TrainingViewModel(private val repository: ChessbookRepository, private val repertoireId: Long) : ViewModel() {
    private val _uiState = MutableStateFlow<TrainingUiState>(TrainingUiState.Loading)
    val uiState: StateFlow<TrainingUiState> = _uiState.asStateFlow()
    val dueCount = repository.getDueCountFlow(repertoireId).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)
    init { loadNextNode() }
    fun loadNextNode() { viewModelScope.launch {
        _uiState.value = TrainingUiState.Loading
        val node = repository.getNextDueNode(repertoireId)
        _uiState.value = if (node == null) TrainingUiState.Empty
        else TrainingUiState.Ready(node, false, listOf(0,1,2,3).map { SM2Algorithm.getIntervalLabel(node, it) })
    }}
    fun revealMove() { (_uiState.value as? TrainingUiState.Ready)?.let { _uiState.value = it.copy(isRevealed = true) } }
    fun rate(quality: Int) { viewModelScope.launch {
        (_uiState.value as? TrainingUiState.Ready)?.let { repository.submitReview(it.node, quality); loadNextNode() }
    }}
    class Factory(private val repository: ChessbookRepository, private val repertoireId: Long) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST") override fun <T : ViewModel> create(modelClass: Class<T>): T = TrainingViewModel(repository, repertoireId) as T
    }
}
